import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innerlayout',
  templateUrl: './innerlayout.component.html',
  styleUrls: ['./innerlayout.component.css']
})
export class InnerlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
