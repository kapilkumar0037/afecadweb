import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginlayout',
  templateUrl: './loginlayout.component.html',
  styleUrls: ['./loginlayout.component.css']
})
export class LoginlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
