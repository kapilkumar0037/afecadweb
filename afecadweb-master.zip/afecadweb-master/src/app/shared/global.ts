export class Global {
    public static IsLoading: boolean;
    public static ClientId: string;
    public static Sever: String="";
    public static NodeApi: String;
    public static FTUTitle:string;
    public static Username: string;
    public static loginType: number;
    public static clientInfo:any={};
    public static Lang:string="";

}