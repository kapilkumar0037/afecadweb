export class StaticData {
    public static WebApiUrl =
        {
            Dev: "http://localhost:56308/",
           
        }
}
