import { Component, OnInit } from '@angular/core';
import { PortalService } from 'src/app/core/services/portal.service';
import {Router } from '@angular/router';

@Component({
  selector: 'app-paymentdetails',
  templateUrl: './paymentdetails.component.html',
  styleUrls: ['./paymentdetails.component.css']
})
export class PaymentdetailsComponent implements OnInit {

  constructor(private service: PortalService , private router : Router) { }
  fileToUpload: File = null;
  paymentDetailsForm: any = {};
  ngOnInit() {
  }
  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
  }

  savePayment(paymentDetailsForm:any) {
    debugger;
    const formData: FormData = new FormData();
    formData.append('Image', this.fileToUpload, this.fileToUpload.name);
    formData.append('data', this.paymentDetailsForm);
    this.service.UploadImage(formData).subscribe((data) => {
      console.log(data);
      this.router.navigate(['/login']);
    }, (error) => {
      console.log(error)
     
    })
  }

  // OnUploadImages() {

  //   this.showSuccess = false;
  //   this.showError = false;
  //   if (this.selectedCourse !== "0") {
  //     let formData: FormData = new FormData();
  //     for (var j = 0; j < this.fileList.length; j++) {
  //       formData.append("file[]" + j.toString(), this.fileList[j], this.fileList[j].name);
  //     }
  //     formData.append("courseId", this.selectedCourse);
  //     this.service.uploadVideos(formData).subscribe((event) => {
  //       if (event) {
  //         if (event.type === HttpEventType.UploadProgress)
  //           this.progress = Math.round(100 * event.loaded / event.total);
  //         else if (event.type === HttpEventType.Response)
  //           this.showSuccess = true;
  //         this.messages.success = "Files Uploaded successfully.";
  //         this.reset();
  //       }
  //     }, (error) => {
  //       this.showSuccess = false;
  //       this.showError = true;
  //       this.messages.error = "Something went wrong! Please try again."
  //     })
  //   }
  //   else {
  //     this.showSuccess = false;
  //     this.showError = true;
  //     this.messages.error = "Please select a course and try again."
  //   }
  // }
  // reset() {
  //   this.inputFile.nativeElement.value="";
  //   this.selectedCourse="0";
  // }
}
