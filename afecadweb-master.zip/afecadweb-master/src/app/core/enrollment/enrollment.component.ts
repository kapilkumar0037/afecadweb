import { Component, OnInit } from '@angular/core';
import { PortalService } from 'src/app/core/services/portal.service';


@Component({
  selector: 'app-enrollment',
  templateUrl: './enrollment.component.html',
  styleUrls: ['./enrollment.component.css']
})
export class EnrollmentComponent implements OnInit {
registraionData: any = [];
  //registraionData = [];
  constructor(private service: PortalService ) { }
 
  ngOnInit() {
    this.GetRegistrationData();
  }
  GetRegistrationData() {
    this.service.getRegistrationData("").subscribe((data) => {
debugger;
      if (data) {
       this.registraionData = data;
        //this.registraionData = Array.of(this.registraionData );
        console.log(data);
      }
    }, (error) => {
      console.log(error)
    })
  }
}
