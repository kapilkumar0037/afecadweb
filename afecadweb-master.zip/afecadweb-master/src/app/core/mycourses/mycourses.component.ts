import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mycourses',
  templateUrl: './mycourses.component.html',
  styleUrls: ['./mycourses.component.css']
})
export class MycoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
