import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completecourse',
  templateUrl: './completecourse.component.html',
  styleUrls: ['./completecourse.component.css']
})
export class CompletecourseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
